var classopt_1_1_payoff_digit_call =
[
    [ "operator()", "classopt_1_1_payoff_digit_call.html#a23b4708d0358e7fc2a5cf886da2db3bb", null ]
];