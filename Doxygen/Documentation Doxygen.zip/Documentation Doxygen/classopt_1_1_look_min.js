var classopt_1_1_look_min =
[
    [ "operator()", "classopt_1_1_look_min.html#adb0feb5d6728344b8d57e21009f41ce9", null ]
];