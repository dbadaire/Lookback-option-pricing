var _aggregator_8h =
[
    [ "opt::Aggregator", "classopt_1_1_aggregator.html", "classopt_1_1_aggregator" ],
    [ "opt::Arithmetic", "classopt_1_1_arithmetic.html", "classopt_1_1_arithmetic" ],
    [ "opt::Geometric", "classopt_1_1_geometric.html", "classopt_1_1_geometric" ],
    [ "opt::LookMax", "classopt_1_1_look_max.html", "classopt_1_1_look_max" ],
    [ "opt::LookMin", "classopt_1_1_look_min.html", "classopt_1_1_look_min" ]
];