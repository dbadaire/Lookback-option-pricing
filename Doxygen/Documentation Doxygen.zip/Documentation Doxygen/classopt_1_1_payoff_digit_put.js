var classopt_1_1_payoff_digit_put =
[
    [ "operator()", "classopt_1_1_payoff_digit_put.html#a88902db6e369b0009b20c56a783c5d4d", null ]
];