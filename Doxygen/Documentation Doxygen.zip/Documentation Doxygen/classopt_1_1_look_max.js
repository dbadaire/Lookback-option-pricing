var classopt_1_1_look_max =
[
    [ "operator()", "classopt_1_1_look_max.html#a2f8caa33927ce60529f5fb0399f1c712", null ]
];