var structopt_1_1_m_c_stats =
[
    [ "ciHigh", "structopt_1_1_m_c_stats.html#a33c3265a727c26aea2a6d6fdeeb9f26a", null ],
    [ "ciLow", "structopt_1_1_m_c_stats.html#a136dcc1034d5540f12c32f6f16b0dcb7", null ],
    [ "estimate", "structopt_1_1_m_c_stats.html#a318f6d478f5bcd3933fadf8170a39c65", null ],
    [ "stdError", "structopt_1_1_m_c_stats.html#ac5c415c1304c05f993303c23c168ad65", null ]
];