var searchData=
[
  ['r_0',['R',['../_exports_8cpp.html#a228eb5e837a644887ac6e7bab3f42485',1,'R:&#160;Exports.cpp'],['../_exports_8h.html#a228eb5e837a644887ac6e7bab3f42485',1,'R:&#160;Exports.h']]],
  ['r_5f_1',['R_',['../classopt_1_1_option.html#aae985c750cc314e5f035b76cfe30d614',1,'opt::Option']]]
];
