var searchData=
[
  ['geometric_0',['Geometric',['../classopt_1_1_geometric.html',1,'opt']]]
];
