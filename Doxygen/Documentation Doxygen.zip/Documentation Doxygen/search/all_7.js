var searchData=
[
  ['lookmax_0',['LookMax',['../classopt_1_1_look_max.html',1,'opt']]],
  ['lookmin_1',['LookMin',['../classopt_1_1_look_min.html',1,'opt']]]
];
