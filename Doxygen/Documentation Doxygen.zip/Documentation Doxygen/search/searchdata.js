var indexSectionsWithContent =
{
  0: "_acdefglmoprstvw~",
  1: "aglmop",
  2: "o",
  3: "adefop",
  4: "_adgmoprstv~",
  5: "ceprst",
  6: "sw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "defines"
};

var indexSectionLabels =
{
  0: "Tout",
  1: "Classes",
  2: "Espaces de nommage",
  3: "Fichiers",
  4: "Fonctions",
  5: "Variables",
  6: "Macros"
};

