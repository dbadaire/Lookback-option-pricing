var classopt_1_1_geometric =
[
    [ "operator()", "classopt_1_1_geometric.html#af00259a79d2d20c8f52c19427612ff85", null ]
];