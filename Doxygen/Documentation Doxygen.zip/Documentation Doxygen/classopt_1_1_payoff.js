var classopt_1_1_payoff =
[
    [ "operator()", "classopt_1_1_payoff.html#aadde14e091e70e0b873cd6f0cc238fa4", null ]
];