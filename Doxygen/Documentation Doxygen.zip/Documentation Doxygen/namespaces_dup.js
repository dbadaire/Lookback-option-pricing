var namespaces_dup =
[
    [ "opt", "namespaceopt.html", "namespaceopt" ]
];