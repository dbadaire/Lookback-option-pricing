var classopt_1_1_aggregator =
[
    [ "operator()", "classopt_1_1_aggregator.html#a190ce37fc68241c737903d640a0fc4dd", null ]
];